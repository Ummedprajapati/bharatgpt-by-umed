// Main Dart file for BharatGPT
void main() => runApp(BharatGPT());